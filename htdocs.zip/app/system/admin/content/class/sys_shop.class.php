<?php
# MetInfo Enterprise Content Management System 
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved. 

defined('IN_MET') or exit('No permission');

class sys_shop{

	public function default_value($list){

	}
	
	public function copy_product($pid,$newid){

	}
	
	public function del_product($pid){

	}
	
	public function save_product($pid,$form){
		
	}
	
	public function para_update($paralist){
		
	}
	
	public function update_product_sql($pid,$paralist,$logistic,$price,$stock,$original,$freight_mould,$freight,$purchase,$message,$user_discount,$lnvoice){
		
	}
	
	public function insert_product_sql($pid,$paralist,$logistic,$price,$stock,$original,$freight_mould,$freight,$purchase,$message,$user_discount,$lnvoice){
		
	}
	
	public function insert_plist($pid,$standard){
		
	}
	public function insert_plist_sql($pid,$price,$valuelist,$stock,$sales){
		
	}
	
	public function get_product($pid){
		
	}
	
	public function get_plist($pid){
		
	}
	
	public function get_para(){
		
	}
	
	public function get_tmpname($tmpname){
		
	}
	
	public function plgin_json_list(){

	}
}

# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>